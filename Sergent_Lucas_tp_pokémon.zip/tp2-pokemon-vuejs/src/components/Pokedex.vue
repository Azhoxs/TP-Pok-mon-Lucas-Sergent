<template>
  <div>
    <Pokemon v-for="pokemon in pokemons" :key="pokemon.name" :pokemon="pokemon" />
  </div>
</template>

<script>
import axios from 'axios';
import Pokemon from './Pokemon.vue';

export default {
  data() {
    return {
      pokemons: [],
    };
  },
  mounted() {
    this.fetchPokemons();
  },
  methods: {
    async fetchPokemons() {
      try {
        const response = await axios.get('https://pokebuildapi.fr/api/v1/pokemon/limit/20');
        this.pokemons = response.data;
      } catch (error) {
        console.error('Error fetching Pokemon data:', error);
      }
    },
  },
  components: {
    Pokemon,
  },
};
</script>

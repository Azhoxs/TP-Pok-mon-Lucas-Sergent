<template>
  <div>
    <Pokedex :pokemons="pokemons" />
  </div>
</template>

<script>
import Pokedex from './components/Pokedex.vue';

export default {
  data() {
    return {
      pokemons: [],
    };
  },
  mounted() {

  },
  components: {
    Pokedex,
  },
};
</script>

<template>
  <div :style="{ backgroundColor: getTypeColor(pokemon.apiTypes[0]) }" class="pokemon-card">
    <img :src="pokemon.image" :alt="pokemon.name" class="pokemon-image" />

    <div class="pokemon-info">
      <h2>{{ pokemon.name }}</h2>

      <div v-for="type in pokemon.apiTypes" :key="type.name" class="type">
        <img :src="type.image" :alt="type.name" class="type-image" />
        <span>{{ type.name }}</span>
      </div>

      <p>Generation: {{ pokemon.apiGeneration }}</p>
    </div>
  </div>
</template>

<script setup>
import "../components/pokemon.css";

// Props
const props = defineProps(["pokemon"]);


const getTypeColor = (type) => {

  const typeColorMap = {
    Plante: "#4CAF50", 
    Feu: "#FF5722", 
    Eau: "#2196F3",
    Insecte: "#CDDC39",
    Normal: "#9E9E9E",
    Poison: "#9C27B0",
    Vol: "#9AF6F2",
    \u00c9lectrik: "#FFEB3B",
    Sol : "#795548",
    Fée : "#E91E63",
    Combat : "#FF9800",
    Psy : "#673AB7",
    Acier : "#607D8B",
  };

  
  return type ? typeColorMap[type.name] || "#FFFFFF" : "#FFFFFF";
};
</script>
<style scoped>
.pokemon-card:hover {
  scale: 1.03;
}
</style>


<template>
    <footer class="footer">
      <p>{{ fullName }} - TP{{ tpNumber }}</p>
    </footer>
  </template>
  
  <script setup>
  const fullName = "Sergent Lucas";
  const tpNumber = "C"; 
  </script>
  
  <style scoped>
  .footer {
    text-align: center;
    padding: 10px;
    bottom: 0;
    width: 100%;
    color: #FFFFFF;
  }
  </style>
<template>
    <div>
      <h2>Liste des Types de Pokémon</h2>
      <ul>
        <li v-for="(count, type) in typesCount" :key="type">
          {{ type }} : {{ count }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      pokemons: Array,
    },
    computed: {
      typesCount() {
        const countMap = {};
        this.pokemons.forEach((pokemon) => {
          const mainType = pokemon.apiTypes[0]?.name || 'Unknown';
          countMap[mainType] = (countMap[mainType] || 0) + 1;

        });
        return countMap;
      },
    },
  };
  </script>
  
  <style scoped>
    ul {
      list-style-type: none;
      padding: 0;
    }
  </style>
<template>
  <div>
    <router-view></router-view>
    <Footer />
  </div>
</template>

<script>
import Pokedex from './components/Pokedex.vue';
import Footer from './components/Footer.vue';

export default {
  data() {
    return {
      pokemons: [],
    };
  },
  mounted() {
  },
  components: {
    Pokedex,
    Footer,
  },
};
</script>

<style>
* {
  background-color: rgb(56, 56, 56);
  color: white;
  font-weight: bold;
}
</style>